import pygame, sys , random
from pygame.key import name

import Library_teens
pygame.init()


#Variables:

clock = pygame.time.Clock()
objects_color = (252,15,3)
player_speed = 0
oponnent_speed = 0
score_player = 0
score_oponnent = 0
screen_h = 600
screen_w = 780

#random_speed:
ball_speed_x = 6 * random.choice((1,-1))
ball_speed_y = 6 * random.choice((1,-1))

#Sound_and_Mixer:

mixer_freq = 8
mixer_size = 5
mixer_channels = 4
mixer_buffer = 7
pygame.mixer.pre_init(frequency=mixer_freq,size= mixer_size,channels=mixer_channels,buffer=mixer_buffer)



#Summons:

screen = Library_teens.Pong.canvas(screen_w, screen_h)
game_name = Library_teens.Pong.game_name('Pong')
game_song = Library_teens.Pong.game_song("pong_music/background_music/background_music_3.mp3")
screen_color = Library_teens.Pong.screen_color((167, 67, 27))
game_font = Library_teens.Pong.game_font("pong_font/pong_font_3.ttf", 32)

###################### WARNING!!! DO NOT TOUCH!! DEADLY POISION.... ##########################################
# <editor-fold desc="nitzanim_variables">
ball = pygame.Rect(screen_w / 2 - 15, screen_h / 2 - 15, 30, 30)
player = pygame.Rect(screen_w - 20, screen_h / 2 - 70, 10, 140)
oponnent = pygame.Rect(10, screen_h / 2 - 70, 10, 140)
# </editor-fold>
# <editor-fold desc="defs_nitzanim">
def ball_animation():
    global ball_speed_x,ball_speed_y,score_player,score_oponnent,oponnent,player
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    if ball.top <= 0 or ball.bottom >= screen_h:
        ball_speed_y *= -1
    if ball.left <= 0:
        score_player += 1
        ball_restart()
    if ball.right >= screen_w:
        score_oponnent += 1
        ball_restart()

    if ball.colliderect(player) or ball.colliderect(oponnent):
        ball_speed_x *= -1.05

def player_animation():
    player.y += player_speed
    if player.top <= 0:
        player.top = 0
    if player.bottom >= screen_h:
        player.bottom = screen_h

def oponnent_ai():
    oponnent.y += oponnent_speed
    if oponnent.top <= 0:
        oponnent.top = 0
    if oponnent.bottom >= screen_h:
        oponnent.bottom = screen_h

def ball_restart():
    global ball_speed_x,ball_speed_y
    ball.center = (screen_w/2, screen_h/2)
    ball_speed_x = 6
    ball_speed_y = 6
    ball_speed_y *= random.choice((1,-1))
    ball_speed_x *= random.choice((1, -1))

def draws():
    screen.fill(screen_color)
    pygame.draw.rect(screen, objects_color, player)
    pygame.draw.rect(screen, objects_color, oponnent)
    pygame.draw.ellipse(screen, objects_color, ball)
    pygame.draw.aaline(screen, objects_color, (screen_w / 2, 0), (screen_w / 2, screen_h))
    player_text = game_font.render(f"{score_player}", False, objects_color)
    screen.blit(player_text, (450, 50))

    oponnent_text = game_font.render(f"{score_oponnent}", False, objects_color)
    screen.blit(oponnent_text, (300, 50))
# </editor-fold>
###################### WARNING!!! DO NOT TOUCH!! DEADLY POISION.... ##########################################















#Game_Loop:
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                player_speed += 10

            if event.key == pygame.K_UP:
                player_speed -= 10

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_DOWN:
                player_speed -= 10

            if event.key == pygame.K_UP:
                player_speed += 10

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_s:
                oponnent_speed += 10
            if event.key == pygame.K_w:
                oponnent_speed -= 10
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_s:
                oponnent_speed -=10
            if event.key == pygame.K_w:
                oponnent_speed +=10

    if score_oponnent <= 5 and score_player <= 5:
        ball_animation()
        player_animation()
        oponnent_ai()
        draws()
        game_song.play()

    else:
        game_song.stop()
    pygame.display.flip()
    clock.tick(60)





