import pygame, sys , random

class Pong:
    def canvas(screen_w, screen_h):
        screen = pygame.display.set_mode((screen_w, screen_h))
        return screen
    def game_name(name):
        the_name = pygame.display.set_caption(name)
        return the_name
    def game_over_screen(game_over):
        game_over_surface = pygame.image.load(game_over).convert_alpha()
        return game_over_surface
    def game_over_song(game_over_song):
        game_over_song = pygame.mixer.Sound(game_over_song)
        return game_over_song
    def game_song(game_music):
        game_song = pygame.mixer.Sound(game_music)
        return game_song
    def screen_color(color):
        bg_color = pygame.Color(color)
        return bg_color
    def game_font(font_file,font_size):
        font_game = pygame.font.Font(font_file, font_size)
        return font_game